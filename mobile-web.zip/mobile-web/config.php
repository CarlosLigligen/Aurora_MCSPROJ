<?php

// $servername = "13.213.119.146";
// $username = "pos";
// $password = "faceloan0099";
// $dbname = "pos";

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pos";
